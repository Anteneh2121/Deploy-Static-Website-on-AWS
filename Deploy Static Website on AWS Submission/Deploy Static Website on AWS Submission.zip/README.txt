
Deploy Static Website on AWS

In this project, I deploy a static website to AWS using S3, CloudFront, and IAM.

Access Website in Web Browser/Web Browser Access

Access the website via website-endpoint

http://my-991900256180-bucket.s3-website-us-east-1.amazonaws.com


Access the website via CloudFront domain name

https://d30bmglhs9jl23.cloudfront.net



Access the bucket object via its S3 object URL

https://my-991900256180-bucket.s3.amazonaws.com/index.html

